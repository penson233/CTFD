var category = document.querySelector('.category');

console.log(category.children);
for (var f = 0; f < category.children.length; f++) {
    console.log(category.children[f].children[0].innerHTML);
    document.querySelector('#' + category.children[f].children[0].innerHTML).style.display = 'none';
}

var first = category.children[0].children[0].innerHTML;

document.querySelector('#' + first).style.display = 'block';

for (var i = 0; i < category.children.length; i++) {
    var children = category.children[i];
    var cate = category.children[i];

    cate.onclick = function() {
        this.style.background = 'black';
        this.style.color = 'white';
        var now = this.children[0].innerHTML;

        for (var j = 0; j < category.children.length; j++) {
            end = category.children[j].children[0].innerHTML;
            if (end != now) {
                category.children[j].style.background = '';
                category.children[j].style.color = 'black';
            }
        }
        var now = this.children[0].innerHTML;
        var get = document.querySelector('#' + now);
        get.style.display = "block";
        for (var k = 0; k < category.children.length; k++) {
            end = document.querySelector('#' + category.children[k].children[0].innerHTML).getAttribute('id');
            if (end != now) {
                document.querySelector('#' + category.children[k].children[0].innerHTML).style.display = "none";
            }

        }
    }

}